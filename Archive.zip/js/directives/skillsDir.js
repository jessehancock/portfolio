angular.module('myPortfolio').directive('skillsDir', function() {

    return {
        templateUrl: '../../views/skillsTmpl.html'
    }

})
