angular.module('myPortfolio').directive('aboutDir', function() {

    return {
        templateUrl: '../../views/aboutTmpl.html'
    }

})
