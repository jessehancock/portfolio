angular.module('myPortfolio').directive('portfolioDir', function() {

    return {
        templateUrl: '../../views/portfolioTmpl.html'
    }

})
