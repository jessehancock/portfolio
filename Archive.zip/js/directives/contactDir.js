angular.module('myPortfolio').directive('contactDir', function() {

    return {
        templateUrl: '../../views/contactTmpl.html'
    }

})
