angular.module('myPortfolio').directive('footerDir', function() {

    return {
        templateUrl: '../../views/footerTmpl.html'
    }

})
