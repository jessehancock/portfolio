angular.module('myPortfolio').controller('landingCtrl', function($scope) {



})
